document.addEventListener("DOMContentLoaded", () => {
    console.log("Studyverse.ai is ready!");
});